import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
# import urlresolver9 as urlresolver
import urllib2


###############################
#######BEGIN ADDON DIRECTORY###
addon_handle = int(sys.argv[1])
###############################
xbmcplugin.setContent(addon_handle, 'movies')

player      = xbmc.Player()
base_url    = sys.argv[0]
url_list    = "http://repo.newfierocket.com/rocket.txt"
args        = urlparse.parse_qs(sys.argv[2][1:])
mode        = args.get('mode', None)
adult_pic   = 'https://images-na.ssl-images-amazon.com/images/M/MV5BMTkxMTA5OTAzMl5BMl5BanBnXkFtZTgwNjA5MDc3NjE@._V1_UX182_CR0,0,182,268_AL_.jpg' 
downloaded_list = {"suck" : "it"}


###put this in as it wouldn't split at the colon
###so sent it to this function
def cleanColon(item):
        clean = item.split('"')
        return clean

def getList(url):
    webfile = urllib.urlopen(url)
    # movie_list = {}
    file_contents = webfile.readlines()
    file_contents = map(str.strip, file_contents)
    movie_list = {}
    
    for item in file_contents:
        clean = cleanColon(item)
        movie_list[clean[0]] = clean[-1]
        xbmc.log(str(movie_list))

    return movie_list

###cleans title from sys.argv to movie and year
###to be sent to NaN
def cleanTitle():
    global downloaded_list
    # xbmc.log(str(downloaded_list),level=xbmc.LOGNOTICE)
    # xbmc.log("###############",level=xbmc.LOGNOTICE)


    movie = str(args['foldername'][0])
    seperate = movie.split('(')
    title = seperate[0]

    # title = title.replace(' ', '&')
    #xbmc.log(str(title))
    # year = seperate[1]
    # year = year.strip('()')
    url = downloaded_list[title]
    play(url, title)


def play(url, movie):
    listitem = xbmcgui.ListItem (movie)
    player.play(url, listitem)


def build_url(query):
    #xbmc.log(str(downloaded_list),level=xbmc.LOGNOTICE)
    built_url = base_url + '?' + urllib.urlencode(query)
    xbmc.log(str(built_url))
    
    return built_url
    
def addFolder(name, icon):
    url = build_url({'mode': name, 'foldername': name})
    li = xbmcgui.ListItem(name, iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

def addMovie(movie, link):
    url = build_url({'mode': 'playmovie', 'foldername': movie})
    li = xbmcgui.ListItem(movie)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=False)


sports_list = getList(url_list)
for movie, link in sports_list.items():
    movie = movie.replace('&', ' ' )
    downloaded_list[movie] = link
    #addMovie(movie, link)
xbmc.log(str(downloaded_list),level=xbmc.LOGNOTICE)

if mode is None:
    addFolder('Sports', adult_pic)
    
elif mode[0] == 'Sports':
    
    my_list = {}
    sports_list = getList(url_list)
    for movie, link in sports_list.items():
        movie = movie.replace('&', ' ' )
        my_list[movie] = link
        addMovie(movie, link)
    downloaded_list = sports_list
    xbmc.log(str(downloaded_list),level=xbmc.LOGNOTICE)

elif mode[0] == 'playmovie':
    cleanTitle()
    

    
#######################################
xbmcplugin.endOfDirectory(addon_handle)
#######################################
